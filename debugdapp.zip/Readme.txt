Locate new/connect/index.html

then search for 'formsubmit'
after which replace the email, just email and you're good to go